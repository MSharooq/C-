/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

class dist
{
    public:
    int feet,inch;
    
    dist(int a,int b)
    {
        feet=a;
        inch=b;
    }
    
    friend void operator + (dist,dist);
    
    void operator < (dist a)
    {
        int totinch1,totinch2;
        totinch1=(feet*12)+inch;
        totinch2=(a.feet*12)+a.inch;
        if(totinch1 < totinch2)
        cout<<"\nsecond distance "<<a.feet<<"ft "<<a.inch<<"inches is greater";
        else if(totinch2 < totinch1)
        cout<<"\nfirst distance "<<feet<<"ft "<<inch<<"inches is greater";
        else
        cout<<"\nboth distance are same";
    }
    
    
    
    
};

void operator + (dist a,dist b)
{
    int totinch;
    totinch=a.inch+(a.feet*12)+b.inch+(b.feet*12);
    cout<<"\nSum is feet="<<(totinch/12)<<"inches="<<totinch%12;
}



int main()
{
    int a,b,c,d;
    cout<<"enter first distance in feet and inches\n";
    cin>>a>>b;
    cout<<"enter second distance in feet and inches\n";
    cin>>c>>d;
    dist p1(a,b);
    dist p2(c,d);
    p1+p2;
    p1<p2;


    return 0;
}



