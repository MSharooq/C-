/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <iostream>
using namespace std;

class convert
{
public:
void decToOctal(int n)
    {
        int octal[100];
        int i = 0,temp=n;
            while (n != 0) 
            {
                octal[i] = n % 8;
                n = n / 8;
                i++;
            }
        cout <<"\nThe Equivalent of "<<temp<<" in octal is";
        for (int j = i - 1; j >= 0; j--)
        cout <<octal[j];
    }
    
void decToHex(int n)
    {
        int hex[100];
        int temp=n;
        int i = 0;
            while (n != 0) 
            {
                hex[i] = n % 16;
                n = n / 16;
                i++;
            }
        cout <<"\nThe Equivalent of "<<temp<<" in hexadecimal is";
        for (int j = i - 1; j >= 0; j--)
        {
        if(hex[j]==10)
        cout <<"A"; 
        
        else if(hex[j]==11)
        cout <<"B";
        
        else if(hex[j]==12)
        cout <<"C"; 
        
        else if(hex[j]==13)
        cout <<"D";
        
        else if(hex[j]==14)
        cout <<"E";
        
        else if(hex[j]==15)
        cout <<"F";
        
        else
        cout <<hex[j];    
        }
    }
 
}con;

 

int main()
{
    int num,num2;
    cout<<"Enter the numbers";
    cin>>num>>num2;
    con.decToHex(num);
    con.decToOctal(num);
    con.decToHex(num2);
    con.decToOctal(num2);
 
    return 0;
}