/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <math.h>
#define PI 3.14

using namespace std;

class shape
{
    public:
    void virtual input(){}
    void virtual area(){}
    void virtual perimeter(){}
    int virtual validity(){return 0;}
};

class triangle : public shape
{
    
    private:
    float a,b,c,area1,peri,s;
    
    public:
    
    int validity()
    {
    if (((a + b) > c) && ((a + c) > b) && ((b + c) > a))
        return 1;
    else
        return 0;
    }
    
    void input()
    {
        cout<<"\nEnter the Sides ";
        cin>>a>>b>>c;
    }
    
    void perimeter()
    {
        peri=(a+b+c);
        cout<<"\n The perimeter is "<<peri;
    }
    
    void area()
    {
        s=peri/2;
        area1= sqrt((s*(s-a)*(s-b)*(s-c)));
        cout<<"\n The area is "<<area1;
    }
       
};

class rectangle: public shape
{
    private:
    float a,b,area1,peri;
    
    public:
    
    void input()
    {
        cout<<"\nEnter the Sides ";
        cin>>a>>b;
    }
    
    void perimeter()
    {
        peri=(a+b)*2;
        cout<<"\n The perimeter is "<<peri;
    }
    
    void area()
   {
       area1= a*b;
       cout<<"\n The area is "<<area1;
   }
};

class circle: public shape
{
    private:
    float r,area1,peri;
    
    public:
    
    void input()
    {
        cout<<"\nEnter the radius ";
        cin>>r;
    }
    void perimeter()
    {
        peri=(2*PI)*r;
        cout<<"\n The perimeter is "<<peri;
    }
    
    void area()
   {
       area1= (PI*r*r);
       cout<<"\n The area is "<<area1;
   }
};

class square: public shape
{
    private:
    float a,area1,peri;
    
    public:
    
    void input()
    {
        cout<<"\nEnter the side ";
        cin>>a;
    }
    
    void perimeter()
    {
        peri=a*4;
        cout<<"\n The perimeter is "<<peri;
    }
    
    void area()
   {
       area1= a*a;
       cout<<"\n The area is "<<area1;
   }
};

int main()
{
    shape *ptr;
    triangle t;
    rectangle r;
    circle c1;
    square s;
    int choice;
    do{
        cout<<"\n**************\n";
        cout<<"\n******SHAPES******\n";
        cout<<"1. Triangle\n2. Rectange\n3. Circle \n4. Square\n5.Exit \nSelect your choice :  ";
        cin>>choice;
    switch (choice)
        {
        case 1:
            ptr = new triangle();
            ptr ->input();
            if( ptr->validity()==1)
            {
                ptr ->perimeter();
                ptr ->area();
                
            }
            else
                cout<<"\nThe given dimensions are Invalid !!!\n";
            break;
        
        case 2:
            ptr = new rectangle();
            ptr ->input();
            ptr ->perimeter();
            ptr ->area();
        
            break;
        
        case 3:
            ptr = new circle();
            ptr ->input();
            ptr ->area();
            ptr ->perimeter();
            
            break;
        
        case 4:
            ptr = new square();
            ptr ->input();
            ptr ->area();
            ptr ->perimeter();
        
            break; 
        
        case 5:
            cout<<"\nEXITING...."<<endl;
            exit(0);  
            break;     
        
        default:
            cout<<"Invalid";
            break;
        }
    }while (choice != 5);
    

    return 0;
}

