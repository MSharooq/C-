/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;


class stringhandling
{
    private:
    char strr[20];
    int len;
    
    public:
    
    void get()
    {
        int i=0;
        cout<<"enter the length\n";
        cin>>len;
        for(i=0;i<len;i++)
        {
            cin>>strr[i];
        }
        strr[len]='\0';
    }
    
    void write()
    {
        int i=0;
        while(i>=0)
        {
            if(strr[i]=='\0')
                {
                i=-1;
                }
            else
            {
            cout<<strr[i];
            i++;
            }
            
        }
    }
    
};

int main()
{
    stringhandling str;
    str.get();
    str.write();

    return 0;
}
