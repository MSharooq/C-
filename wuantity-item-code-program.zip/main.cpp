/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class product
{
  public:
  int item_code,quantity;
  float price,amount;
  
  void total()
  {
      amount=quantity*price;
  }
  
  void display()
  {
      cout<<"\t"<<item_code<<"\t\t"<<price<<"\t\t"<<quantity<<"\t";
      printf("%.3f",amount);
  }
}list[100];

int main()
{
    int n,i=0;
    cout<<"\nenter the number of products";
    cin>>n;
    while(i<n)
    {
        cout<<"\nenter item code";
        cin>>list[i].item_code;
        cout<<"\nenter quantity";
        cin>>list[i].quantity;
        cout<<"\nenter price";
        cin>>list[i].price;
        i++;
    }
    
    cout<<"Sl No\tItem Code\tQuantity\tPrice\tAmount";
    i=0;
    while(i<n)
    {
        cout<<"\n"<<(i+1);
        list[i].total();
        list[i].display();
        i++;
    }
    return 0;
}
