/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <math.h>
using namespace std;

class triangle
{
    
    public:
    int x1,y1,x2,y2,x3,y3;
    float d1,d2,d3;

    inline int validator()
    {
        if(0.5*((x1*(y2-y3))+(x2*(y3-y1))+(x3*(y1-y2)))!=0)
        return 1;
        else 
        return 0;
    }
    
    inline void distfinder()
    {
       d1= sqrt(pow(x2-x1,2)+pow(y2-y1,2));
       d2= sqrt(pow(x3-x2,2)+pow(y3-y2,2));
       d3= sqrt(pow(x1-x3,2)+pow(y1-y3,2));
    }
    
    inline void shortdist()
    {
        if((d1<d2) && (d1<d3))
        cout<<"\nthe distance between a"<<x1<<" "<<y1<<"and b"<<x2<<" "<<y2<<" is the shortest "<<d1;
        else if((d2<d1) && (d2<d3))
        cout<<"\nthe distance between b"<<x2<<" "<<y2<<" and c"<<x3<<" "<<y3<<" is the shortest "<<d2;
        else ((d3<d1) && (d3<d2));
        cout<<"\nthe distance between a"<<x1<<" "<<y1<<" and c"<<x3<<" "<<y3<<" is the shortest "<<d3;
    }
}t;


int main()
{

    cout<<"Enter the coordinates of point a in x1,y1\n";
    cin>>t.x1>>t.y1;
    cout<<"Enter the coordinates of point b in x2,y2\n";
    cin>>t.x2>>t.y2;
    cout<<"Enter the coordinates of point c in x3,y3\n";
    cin>>t.x3>>t.y3;
    
    if(t.validator()==1)
    {
        t.distfinder();
        t.shortdist();
    }
    else
    cout<<"the sides are not valid";

    return 0;
}
