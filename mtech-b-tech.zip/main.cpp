/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class student 
{
    protected:
    string name;
    int age;
    double reg_no;
    

    public:
    student()
    {
        cout<<"enter the name\n";
        cin>>name;
        cout<<"enter the age\n";
        cin>>age;
        cout<<"enter the reg no\n";
        cin>>reg_no;
    }
    virtual void sort(){};
    
};

class B_Tech: public student
{
    protected:
    int marks;
    
    public:
    
    B_Tech()
    {
        student();
        cout<<"enter THE marks\n";
        cin>>marks;
    }
    
    void sort(int n)
    {
    for (int i = 0; i < n - 1; ++i) 
        {
        for (int j = 0; j < n - i - 1; ++j)
            {
            if (this[i].marks > this[i + 1].marks) 
                {
                    B_Tech temp = this[i];
                    this[i] = this[i + 1];
                    this[i + 1] = temp;
                }
            if(this[i].marks == this[i+1].marks)
                {
                    if((this[i].name.compare(this[i+1].name)) < 0)
                    {      
                        B_Tech temp = this[i]; 
                        this[i] = this[i + 1];
                        this[i + 1] = temp;
                    } 
                }
            }
        }
    }
    
    void getval()
        {
            cout << "Name :: ";
            cin >> name;
            cout <<"Age :: ";
            cin >> age;
            cout << "Registration Number :: ";
            cin >> reg_no;
            cout << "Marks :: ";
            cin >> marks;
        }
        
    void display()
    {
        cout<<"\nName:"<<name;
        cout<<"\nAge:"<<age;
        cout<<"\nReg_no:"<<reg_no;
        cout<<"\nMarks:"<<marks;
    }
    
};

class M_Tech: public student
{
    protected:
    float gpa;
    
    public:
    
    M_Tech()
    {
        student();
    }
    
    void sort(int n)
    {
    for (int i = 0; i < n - 1; ++i) 
        {
        for (int j = 0; j < n - i - 1; ++j)
            {
            if (this[i].gpa > this[i + 1].gpa) 
                {
                    M_Tech temp = this[i];
                    this[i] = this[i + 1];
                    this[i + 1] = temp;
                }
            if(this[i].gpa == this[i+1].gpa)
                {
                    if((this[i].name.compare(this[i+1].name)) < 0)
                    {      
                        M_Tech temp = this[i]; 
                        this[i] = this[i + 1];
                        this[i + 1] = temp;
                    } 
                }
            }
        }
    }
    
    void getval()
        {
            cout << "Name :: ";
            cin >> name;
            cout <<"Age :: ";
            cin >> age;
            cout << "Registration Number :: ";
            cin >> reg_no;
            cout << "GPA :: ";
            cin >> gpa;
        }
    
    void display()
    {
        cout<<"\nName:"<<name;
        cout<<"\nAge:"<<age;
        cout<<"\nReg_no:"<<reg_no;
        cout<<"\nGpa:"<<gpa;
    }
};

int main()
{
    int choice,size;
    do
    {

    cout<<"============Welcome===========\n";
    cout<<"=Press 1 for Btech students===\n";
    cout<<"=Press 2 for Mtech students===\n";
    cout<<"=Press any other to exit===\n";
    cin>>choice;
    
    switch (choice)
    {
        case 1:cout<<"Enter the number of students";
               cin>>size;
               B_Tech array[size];
               for( int i = 0; i < size; ++i)
                    {
                        cout << "Student #" << i+1<<endl;
                        array[i].getval();
                    }
               break;
        
        case 2:cout<<"Enter the number of students";
                cin>>size;
                M_Tech array1[size];
                for( int i = 0; i < size; ++i)
                    {
                        cout << "Student #" << i+1<<endl;
                        array1[i].getval();
                    }
                break;
        default:cout<<"Wrong input";
                break;
    }
    }while(choice!= 1&&choice!= 2);

    return 0;
}
