/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include<math.h>
using namespace std;

class triangle 
{
    private:
       double a, b, c, s, area;
       int valid=0;
       
    public:
    void input()
    {             
    cout<<"Enter the sides of triangle : ";
    cin>>a>>b>>c;
    }
    
    void validate()
    {             
    if(a+b<=c||b+c<=a||a+c<=b)
    valid=0;
    else
    valid++;
    }
    
    void display()
    {            
    s = (a+b+c)/2;
    area = sqrt(s*(s-a)*(s-b)*(s-c));
    if(valid==1)
    {
        cout<<"sides are valid\n"<<"Area is"<<area<<"\nSides are"<<"\nA="<<a<<"\nB="<<b<<"\nC="<<c<<"\nSemi Perimeter is"<<s;
    }
    else
    cout<<"sides are not valid\n";
    }
   
}tri;


int main()
{
    tri.input();
    tri.validate();
    tri.display();
    
    return 0;
} 
