/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <math.h>

using namespace std;

class polar
{
    private:
        float angle,radius;
    
    public:
        polar(){}
        polar(float a, float b)
        {
            angle=b;radius=a;
        }
        
        float getangle()
        {
            return angle;
        }
        float getradius()
        {
            return radius;
        }
};

class rectangular
{
    private:
        float x,y;
    public:
    
        rectangular(){}
        
        rectangular(float a, float b)
        {
            x=a;y=b;
        }
        
        rectangular(polar temp)
        {
          int r=temp.getradius(); 
          int a=temp.getangle();
          
          x=r*cos(a);y=r*sin(a);
        }
        
        void display()
        {
            cout<<"\nx coordinate is "<<x;
            cout<<"  y coordinate is "<<y;
        }
    
        
};


int main()
{
    float r,a;
    cout<<"Enter polar coordinates as radius and angles in radians\n";
    cin>>r>>a;
    polar p1(r,a);
    rectangular p2;
    p2=p1;
    p2.display();
    
    

    return 0;
}
