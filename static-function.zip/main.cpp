/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class IntManipulator
{
   
    public:
    static int length;
    static int arr[10];
    static void averageCalculator(int length);
    
    void input()
    {
        cout<<"How many integers?";
        cin>>length;
        cout<<"Enter any "<<length<<" integers: ";
        for(int i = 0;i<length;i++)
        {
            cin>>arr[i];
        }
    }
    
    void multiply ()
    {
        int multiplier;
        cout<<"\nEnter the number you want to multiply with ";
        cin>>multiplier;
        
        for(int i = 0; i<length;i++)
        {
            int temp = arr[i];
            arr[i] = multiplier*temp;
        }
    }
    
    void sort()
    {
        int swap;
        for(int i = 0;i<length;i++)
        {
            for(int j = i+1;j<length;j++)
            {
                if(arr[i]>arr[j]){
                    swap = arr[i];
                    arr[i] = arr[j];
                    arr[j] = swap;
                }
            }
        }
        
        cout<<"\nSorted array is: ";
        for(int i = 0; i<length;i++)
        {
            cout<<arr[i]<<" ";
        }

    }    

};

int IntManipulator :: length = 0;
int IntManipulator :: arr[10] = {1,2};
  void IntManipulator :: averageCalculator(int length)
  {
        double average;
        int sum=0;
        for(int i=0;i<length;i++)
        {
            sum += arr[i];  
        }
        average = sum/length;
        
        cout<<"Average of the new array is: "<<average;
    }
int main()
{
    IntManipulator a,b,c;
    a.input();
    a.averageCalculator(a.length);
    b.multiply();
    a.averageCalculator(a.length);
    c.sort();
}