/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;


class date
{
    public:
    int dd,mm,yyyy;
};

class student: private date
{
    private:
    string name;
    int age;
    date dob;
    
    public:
    void input()
    {
        cout<<"enter the name of the student\n";
        cin>>name;
        cout<<"enter the age of the student\n";
        cin>>age;
        cout<<"enter the dob of student in dd/mm/yyyy format\n";
        cin>>dob.dd>>dob.mm>>dob.yyyy;
    }
    
    void output()
    {
        cout<<name<<"......."<<dob.dd<<"/"<<dob.mm<<"/"<<dob.yyyy<<"\n";
    }
}stu[10];

int main()
{
    int i;
    for(i=0;i<10;i++)
    {
      stu[i].input();
    }
    
    cout<<"slno\tName\t\tDate of Birth\n";
    cout<<"====\t====\t\t=============\n";
    
    for(i=0;i<10;i++)
    {
      cout<<i+1<<"......";
      stu[i].output();
    }
    

    return 0;
}
