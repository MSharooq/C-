/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int opt=1;

class bank
{
    private:
    struct BankAccount
    {
        string accholder;
        int accbal=0;
        int accno;
        string acctype;
    }bankdetails[2];
    
    public:
    
    void assign()
    {
        cout<<"Assigning values to the accounts\n";
        
        for(int i=0;i<2;i++)
        {
            cout<<"Enter name of account holder\n";
            cin>>bankdetails[i].accholder;
            cout<<"Enter account number\n";
            cin>>bankdetails[i].accno;
            cout<<"Enter acc Type\n";
            cin>>bankdetails[i].acctype;
            cout<<"============================================\n\n";
            
        }
        cout<<"Data Base updated succesfully\n";
        cout<<"============================================\n\n";
    };

    void deposit()
    {
        int temp,count=0,i;
        cout<<"Enter the account number to which the money is to be deposited\n";
        cin>>temp;
        for(i=0;i<2;i++)
        {
            if(bankdetails[i].accno == temp)
            {
                cout<<"Current balance is"<<bankdetails[i].accbal<<"\n";
            }
        }
        
        int amount;
        cout<<"Enter the amount to be deposited\n";
        cin>>amount;
        if(amount>0)
            {
                   bankdetails[i].accbal+=amount;
                   cout<<"Amount has been deposited succesfully\n";
                   cout<<"Current balance is"<<bankdetails[i].accbal<<"\n";
                   cout<<"============================================\n\n";
                   count++;  
                
            } 
            
        if(count==0)
        {
        cout<<"Couldnt find the entered bank account please check the entered number\n";
        cout<<"============================================\n\n";
        }
    };
    
    
    
    void withdraw()
    {
        int temp,count=0,i;
        cout<<"Enter the account number to which the money is to be withdrawn\n";
        cin>>temp;
        
        for(i=0;i<2;i++)
        {
            if(bankdetails[i].accno == temp)
            {
                cout<<"Current balance is"<<bankdetails[i].accbal<<"\n";
            }
        }
        
        int amount;
        cout<<"Enter the amount to be withdrawn\n";
        cin>>amount;
        if(amount>0)
        {
            if(bankdetails[i].accbal>=amount)
                {
                   bankdetails[i].accbal-=amount;
                   cout<<"Amount has been withdrawn succesfully\n";
                   cout<<"Current balance is"<<bankdetails[i].accbal<<"\n";
                   cout<<"============================================\n\n";
                   count++;  
                }
        
            else
            {
            cout<<"Amount exceeds the bank balance\n";
            cout<<"============================================\n\n";
            }
        }
            
        if(count==0)
        {
        cout<<"Couldnt find the entered bank account please check the entered number\n";
        cout<<"============================================\n\n";
        }

    };
    
    
    
    void details()
    {
        int temp,count=0;
        cout<<"Enter the account number\n";
        cin>>temp;
        
        for(int i=0;i<2;i++)
        {
            if(bankdetails[i].accno == temp)
            {
              cout<<"name of account holder\t"<<bankdetails[i].accholder<<"\n";
            cout<<"account number\t"<<bankdetails[i].accno<<"\n";
            cout<<"acc Type\t"<<bankdetails[i].acctype<<"\n";
            cout<<"============================================\n\n";
            
              count++;  
            }
        }
        if(count==0)
        {
        cout<<"Couldnt find the entered bank account please check the entered number\n";
        cout<<"============================================\n\n";
        }
    };
    
    
}bankbranch1;

int mainpage()
{
    int option;
   cout<<"============================================\n";
   cout<<"============WELCOME TO URBANK===============\n";
   cout<<"============================================\n\n";
   cout<<"==Press 1 ==================================\n";
   cout<<"==Assign initial Values=====================\n\n";
   cout<<"==Press 2 ==================================\n";
   cout<<"==Deposit Funds=============================\n\n";
   cout<<"==Press 3 ==================================\n";
   cout<<"==Withdraw Funds============================\n\n";
   cout<<"==Press 4 ==================================\n";
   cout<<"==To see Bank details=======================\n\n";
   cout<<"==Press 5 ==================================\n";
   cout<<"==To exit=======================\n\n";
   cout<<"============================================\n";
   cin>>option;
   return (option);
}

void interface(int a)
{
    switch(a)
    {
        case 1:bankbranch1.assign();
        break;
        case 2:bankbranch1.deposit();
        break;
        case 3:bankbranch1.withdraw();
        break;
        case 4:bankbranch1.details();
        break;
        case 5:opt=0;
        break;
    }
    if(a<=0 || a>5)
    cout<<"entered input is wrong";
}



int main()
{
    do
    {
    interface(mainpage());
    }while(opt==1);
   
    return 0;
}
