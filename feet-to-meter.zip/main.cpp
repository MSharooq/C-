/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class dist
{
 public:
 float feet,inches;
 
 
 dist(float a, float b)
 {
    feet=a;inches=b;
 }
 
};

void meterToImperial(float m)
{
    int totinch=m*39.37;
    cout<<"\n"<<m<<" meters is"<<totinch/12<<"ft "<<totinch%12<<"inch";
}

void imperialToMeter(dist a)
{
    int totinch=(a.feet*12)+a.inches;
    cout<<"\n"<<totinch/12<<"ft "<<totinch%12<<"inch is "<<(totinch*0.0254)<<"meters";
   
}

int main()
{
    float a,b,c;
    cout<<"Enter feet and inches\n";
    cin>>a>>b;
    cout<<"Enter meter\n";
    cin>>c;
    dist d1(a,b);
    meterToImperial(c);
    imperialToMeter(d1);
    return 0;
}

