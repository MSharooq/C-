/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
 
class complex {
   private:
      int real;             
      int img;           
      
   public:
      complex() 
      {
         real = 0;
         img = 0;
      }
      complex(int f, int i) 
      {
         real = f;
         img = i;
      }
      
      friend ostream &operator <<( ostream &output, const complex &D ) 
      { 
         output <<D.real << " + i " << D.img;
         return output;            
      }

      friend istream &operator >>( istream  &input, complex &D ) 
      { 
         input >> D.real >> D.img;
         return input;            
      }
};

int main() {
   
   complex D1;
   cout << "Enter the complex number of object : " << endl;
   cin >> D1;
   cout << "Complex number : " << D1 << endl;

   return 0;
}

