/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class date
{
    private:
    int DD,MM,YYYY,valid=0;
    bool leap;
    
    public:
    int check()
    {
      cout<<"Enter date";
      cin>>DD;
      cout<<"Enter Month";
      cin>>MM;
      cout<<"Enter Year";
      cin>>YYYY;
      
      if((DD<=31 && MM<=12 && YYYY<=9999))    //checking the validity of the date
     {
        if(YYYY%4==0 && YYYY%100==0 && YYYY%400==0)
        {
            leap=true;
        }
        
        if(MM==1||MM==3||MM==5||MM==7||MM==8||MM==10||MM==12)
           {
              if(DD<=31)
                 {
                 valid++;
                 }  
           }
           
        if(MM==4||MM==6||MM==9||MM==11)
        {
            if(DD<=30)
            {
                valid++;
            }
        }
        
        if(MM==2&&leap==true)
        {
            if(DD<=29)
            valid++;
        }
        else
        if(DD<=28)
        valid++;
        }
        
        
     return (valid);
    }
    
    
    void nextdate()
    {
        if(MM==1||MM==3||MM==5||MM==7||MM==8||MM==10||MM==12)  //START of next date computing of every                       month ending with 31 days
        {
            if(DD==31)
            {
                if(MM==12)
                {
                    DD=1;MM=1;YYYY++;
                }
                else
                DD=1,MM++;
            }
            else
            DD++;
        }                                                      //END of next date computing of every month ending with 31 days
        
        
        else if(MM==4||MM==6||MM==9||MM==11)                        //START of next date computing of every month ending with 30 days
        {
            if(DD==30)
            {
            DD=1;MM++;
            }
            else
            DD++;
        }                                                       //END of next date computing of every month ending with 30 days
        
        
        else if(MM==2)                                               //START of next date computing of february
           {
            if(leap)
            {
              if(DD==29)
                 {
                   DD=1;MM++;
                 }
                 else 
                 DD++;
            }
            else if(DD==28)
            {
                DD=1;MM++;
            }
            else if(DD<28)
            {
                DD++;
            }
           }                                                        //END of next date computing of february
        
        cout<<DD<<"/"<<MM<<"/"<<YYYY<<"\n";                     //Printing Of next date
    }
}D1;


int main()                                                      
{
    if(D1.check()>0)
    {
    cout<<"Valid\n";    
    D1.nextdate();
    }
    else
    cout<<"Not Valid\n";

    return 0;
}                                                               
