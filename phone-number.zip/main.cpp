/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

struct phone
{
    int area_code;
    int exchange;
    int number;
}n1,n2;

int main()
{
   n1.area_code=123;
   n1.exchange=578;
   n1.number=5555; 
    
 cout<<"-Enter the number-\nenter area code\n";
 cin>>n2.area_code;
 cout<<"enter exchange\n";
 cin>>n2.exchange;
 cout<<"enter number\n";
 cin>>n2.number;
 
 cout<<"My number "<<n1.area_code<<" "<<n1.exchange<<" "<<n1.number<<"\n";
 cout<<"Your number "<<n2.area_code<<" "<<n2.exchange<<" "<<n2.number<<"\n";
 
 return 0;
}
