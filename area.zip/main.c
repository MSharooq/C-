#include <stdio.h>
int main()
{
float unit;
float amt;
printf("Enter total units consumed: ");
scanf("%f", &unit);
if(unit <= 100)
{
amt = unit * 1;
}
else if(unit>100 && unit<=300)
{
amt = 100 + ((unit-100) * 2);
}
else
{
amt = 500 + ((unit-300) * 3);
}
printf("Electricity Bill = Rs. %f", amt);
return 0;
}