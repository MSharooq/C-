/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class date
{
    private:
    int dd,mm,yyyy,valid=0,max[12]={31,28,31,30,31,30,31,31,30,31,30,31},leap;
    
    
    public:
    
    date(int a, int b, int c)
    {
        dd=a;mm=b;yyyy=c;
    }
    
    int check()
    {
      if((yyyy%4 && yyyy%100 && yyyy%400) == 0)
          {
          leap=1;
          max[1]=29;
          }
      
      
      if(yyyy<=9999 && yyyy>0)
          {
          if(mm<=12 && mm>0)
            {
             if(dd>0 && dd<= max[mm-1])
                {
                  valid=1; 
                }
            }
          }
          return valid;
    }
    
    
    void operator + (int a)
    {
     dd=dd+a;
     while(dd>max[mm-1])
     {
       dd=dd-max[mm-1];
       mm++;
       if(mm==13)
       mm=1;
     }
    }
    
    void display()
    {
        cout<<"\nthe date is "<<dd<<"/"<<mm<<"/"<<yyyy;
    }
};


int main()                                                      
{
    int a,b,c,num;
    cout<<"enter the date in dd/mm/yyyy order\n";
    cin>>a>>b>>c;
    date d1(a,b,c);
    cout<<"enter the date which is to be added\n";
    cin>>num;
    if(d1.check()==1)
    {
        d1+num;
    }
    d1.display();
    return 0;
}                                                               







