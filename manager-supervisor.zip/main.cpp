/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string.h>
using namespace std;

int const totalWorkingHours = 160; 

class Employee
{
protected:
     char name[10];
     int empNo;
     float payRate;
public:
 
 Employee() {}
 
 void getEmployeetData()
 {
 cout << "ENTER DETAILS bELOW" << endl;
 cout << "--------------------------------" << endl;
 cout << "name:" << endl;
 cin >> name;
 cout << "employment no." << endl;
 cin >> empNo;
 cout << "pay rate:" << endl;
 cin >> payRate;
 }
 
 virtual float pay(){return 0;} 
 
 void displayEmployeeData()
 {
 cout << "============" << endl;
 cout << "Name of employee: " << name << endl;
 cout << "Employment No. " << empNo << endl;
 cout << "Pay rate " << payRate << endl;
 cout << "Salary: " << pay() << endl;
 cout << "============";
 }
};

class Manager : public Employee
{
     private:
        bool isSalaried;
        int workingHours;
    
     public:
     void getManagerData()
     {
         cout << "ENTER 0 IF SALARIED HOURLY ELSE ENTER 1" << endl;
         cin >> isSalaried;
         if (!isSalaried)
         {
             cout << "ENTER WORKING HOURS" << endl;
             cin >> workingHours;
         }
     }
     
     float pay()
     {
         if (isSalaried)
         return payRate * totalWorkingHours;
         else
         return payRate * workingHours;
     }
};

class Supervisor : public Employee
{
    private:
        string department;
    
    public:
         void getSupervisorData()
         {
             cout << "\n Department: ";
             cin >> department;
         }
         
         float pay()
         {
            return payRate * totalWorkingHours;
         }
         
         void displayDepartment()
         {
             cout<<"\nDepartment is "<<department;
         }
};

int main()
 { 
 Manager M1;
 Supervisor S;
 int choice;
 cout << "============"<<"\nPRESS 1 FOR MANAGER\nPRESS 2 TWO FOR SUPERVISOR\n===========";
 cin >> choice;
 
 switch (choice)
     { 
        case 1: M1.getEmployeetData();
                M1.getManagerData();
                M1.displayEmployeeData();
                break;
        case 2: S.getEmployeetData();
                S.getSupervisorData();
                S.displayEmployeeData();
                S.displayDepartment();
                break;
     
        default:cout << "\n INVALID";
     };
 
 return 0;
}
